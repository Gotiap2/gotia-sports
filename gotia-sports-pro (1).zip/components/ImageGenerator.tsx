import React, { useState } from 'react';
import { generateVisual } from '../services/geminiService';
import { Sparkles, Download, Loader2, Image as ImageIcon } from 'lucide-react';

const ASPECT_RATIOS = ["1:1", "3:4", "4:3", "9:16", "16:9"];
const RESOLUTIONS = ["1K", "2K", "4K"];

export const ImageGenerator: React.FC<{ defaultPrompt?: string }> = ({ defaultPrompt = "" }) => {
  const [prompt, setPrompt] = useState(defaultPrompt);
  const [aspectRatio, setAspectRatio] = useState("1:1");
  const [imageSize, setImageSize] = useState("1K");
  const [loading, setLoading] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt) return;
    setLoading(true);
    const result = await generateVisual(prompt, aspectRatio, imageSize);
    setGeneratedImage(result);
    setLoading(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center gap-3 mb-4">
        <div className="p-3 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 shadow-lg shadow-purple-500/20">
          <ImageIcon className="text-white" size={24} />
        </div>
        <div>
           <h3 className="text-xl font-black text-white uppercase italic tracking-tighter">Studio Visual</h3>
           <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Genera arte de tus victorias</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 space-y-5">
           <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Prompt Creativo</label>
            <textarea 
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Ej: Un estadio futurista celebrando una victoria del Real Madrid con fuegos artificiales de neón..."
              className="w-full h-32 p-4 rounded-2xl bg-slate-900/50 border border-slate-700 text-white text-xs font-medium focus:border-indigo-500 outline-none resize-none transition-all"
            />
           </div>

           <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Formato</label>
                <select 
                  value={aspectRatio}
                  onChange={(e) => setAspectRatio(e.target.value)}
                  className="w-full p-3 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-bold outline-none focus:border-indigo-500"
                >
                  {ASPECT_RATIOS.map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Calidad</label>
                <select 
                  value={imageSize}
                  onChange={(e) => setImageSize(e.target.value)}
                  className="w-full p-3 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-bold outline-none focus:border-indigo-500"
                >
                  {RESOLUTIONS.map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>
           </div>

           <button 
            onClick={handleGenerate}
            disabled={loading || !prompt}
            className="w-full py-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-black uppercase tracking-[0.2em] text-xs flex items-center justify-center gap-3 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-indigo-600/20"
           >
             {loading ? <Loader2 className="animate-spin" size={16}/> : <Sparkles size={16}/>}
             {loading ? 'Renderizando...' : 'Generar Arte'}
           </button>
        </div>

        <div className="md:col-span-2 bg-slate-900/50 border border-slate-800 rounded-3xl flex items-center justify-center min-h-[400px] relative overflow-hidden group">
          {generatedImage ? (
            <>
              <img src={generatedImage} alt="Generated" className="w-full h-full object-contain" />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center backdrop-blur-sm">
                <a href={generatedImage} download="gotia-art.png" className="bg-white text-black px-6 py-3 rounded-full font-black uppercase tracking-widest text-xs flex items-center gap-2 hover:scale-105 transition-transform">
                  <Download size={16} /> Descargar
                </a>
              </div>
            </>
          ) : (
            <div className="text-center opacity-20">
              <Sparkles className="w-16 h-16 mx-auto mb-4" />
              <p className="text-xs font-black uppercase tracking-[0.3em]">Esperando inspiración...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};