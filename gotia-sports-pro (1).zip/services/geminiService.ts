import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || ''; // Ensure API_KEY is set in environment
const ai = new GoogleGenAI({ apiKey });

export const analyzeMatch = async (match: string, competition: string, market: string): Promise<string> => {
  if (!apiKey) return "API Key missing.";
  try {
    const prompt = `Analiza brevemente el partido ${match} en ${competition} para el mercado de apuestas: ${market}. Dame una probabilidad estimada en porcentaje y un consejo corto de 2 lineas.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: "Eres un experto analista deportivo de alto nivel (Tipster Pro). Sé directo, usa datos estadísticos y mantén un tono profesional.",
      }
    });
    return response.text || "No se pudo generar el análisis.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error al conectar con la IA.";
  }
};

export const generateVisual = async (prompt: string, aspectRatio: string, imageSize: string): Promise<string | null> => {
  if (!apiKey) return null;
  try {
    // Mapping aspect ratio keywords to supported Enum-like strings if needed, 
    // but the API accepts strict strings: "1:1", "3:4", "4:3", "9:16", "16:9"
    
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [{ text: prompt }]
      },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio, 
          imageSize: imageSize 
        }
      }
    });

    // Extract image from response
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Gemini Image Gen Error:", error);
    return null;
  }
};